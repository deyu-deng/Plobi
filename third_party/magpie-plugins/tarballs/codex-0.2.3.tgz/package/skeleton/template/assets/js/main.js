$(document).ready(function() {
  // :D
});